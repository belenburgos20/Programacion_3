const { Categoria } = require("../models/entities/categorias.js");

const list = async (req, res) => {
  try {
    const categorias = await Categoria.findAll();
    res.status(200).json(categorias);
  } catch (error) {
    console.error("Error al listar categorías:", error);
    res.status(500).json({ error: "Error al listar categorías" });
  }
}

const create = async (req, res) => {
  try {
    const { nombre } = req.body;
    if (!nombre) {
      return res.status(400).json({ error: "El nombre es requerido" });
    }
    const nuevaCategoria = await Categoria.create({ nombre });
    res.status(201).json(nuevaCategoria);
  } catch (error) {
    console.error("Error al crear categoría:", error);
    res.status(500).json({ error: "Error al crear categoría" });
  }
}

const update = async (req, res) => {
  try {
    const { id } = req.params;
    const { nombre } = req.body;
    if (!nombre) {
      return res.status(400).json({ error: "El nombre es requerido" });
    }
    const categoria = await Categoria.findByPk(id);
    if (!categoria) {
      return res.status(404).json({ error: "Categoría no encontrada" });
    }
    categoria.nombre = nombre;
    await categoria.save();
    res.status(200).json(categoria);
  } catch (error) {
    console.error("Error al actualizar categoría:", error);
    res.status(500).json({ error: "Error al actualizar categoría" });
  }
}

const remove = async (req, res) => {
  try {
    const { id } = req.params;
    const categoria = await Categoria.findByPk(id);
    if (!categoria) {
      return res.status(404).json({ error: "Categoría no encontrada" });
    }
    await categoria.destroy();
    res.status(204).send();
  } catch (error) {
    console.error("Error al eliminar categoría:", error);
    res.status(500).json({ error: "Error al eliminar categoría" });
  }
}

const getCategoriaPorId = async (req, res) => {
  try {
    const { id } = req.params;
    const categoria = await Categoria.findByPk(id);
    if (!categoria) {
      return res.status(404).json({ error: "Categoría no encontrada" });
    }
    res.status(200).json(categoria);
  } catch (error) {
    console.error("Error al obtener categoría por ID:", error);
    res.status(500).json({ error: "Error al obtener categoría por ID" });
  }
};

const getCategoriaPorNombre = async (req, res) => {
  try {
    const { nombre } = req.params;
    const categoria = await Categoria.findOne({ where: { nombre } });
    if (!categoria) {
      return res.status(404).json({ error: "Categoría no encontrada" });
    }
    res.status(200).json(categoria);
  } catch (error) {
    console.error("Error al obtener categoría por nombre:", error);
    res.status(500).json({ error: "Error al obtener categoría por nombre" });
  }
}; 

module.exports = {
  list,
  create,
  update,
  remove,
  getCategoriaPorId,
  getCategoriaPorNombre
};
