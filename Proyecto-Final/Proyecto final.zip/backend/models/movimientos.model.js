const { Movimiento } = require("../models/entities/movimientos.js");

const list = async (req, res) => {
  try {
    const movimientos = await Movimiento.findAll();
    res.status(200).json(movimientos);
  } catch (error) {
    console.error("Error al listar movimientos:", error);
    res.status(500).json({ error: "Error al listar movimientos" });
  }
}

const create = async (req, res) => {
  try {
    const { tipo, fecha, id_categoria, descripcion, total } = req.body;
    if (!tipo || !fecha || !id_categoria || !total) {
      return res.status(400).json({ error: "Todos los campos son requeridos" });
    }
    const nuevoMovimiento = await Movimiento.create({ tipo, fecha, id_categoria, descripcion, total });
    res.status(201).json(nuevoMovimiento);
  } catch (error) {
    console.error("Error al crear movimiento:", error);
    res.status(500).json({ error: "Error al crear movimiento" });
  }
}

const update = async (req, res) => {
  try {
    const { id } = req.params;
    const { tipo, fecha, id_categoria, descripcion, total } = req.body;
    if (!tipo || !fecha || !id_categoria || !total) {
      return res.status(400).json({ error: "Todos los campos son requeridos" });
    }
    const movimiento = await Movimiento.findByPk(id);
    if (!movimiento) {
      return res.status(404).json({ error: "Movimiento no encontrado" });
    }
    movimiento.tipo = tipo;
    movimiento.fecha = fecha;
    movimiento.id_categoria = id_categoria;
    movimiento.descripcion = descripcion;
    movimiento.total = total;
    await movimiento.save();
    res.status(200).json(movimiento);
  } catch (error) {
    console.error("Error al actualizar movimiento:", error);
    res.status(500).json({ error: "Error al actualizar movimiento" });
  }
}

const remove = async (req, res) => {
  try {
    const { id } = req.params;
    const movimiento = await Movimiento.findByPk(id);
    if (!movimiento) {
      return res.status(404).json({ error: "Movimiento no encontrado" });
    }
    await movimiento.destroy();
    res.status(204).send();
  } catch (error) {
    console.error("Error al eliminar movimiento:", error);
    res.status(500).json({ error: "Error al eliminar movimiento" });
  }
}

const getMovimientoPorId = async (req, res) => {
  try {
    const { id } = req.params;
    const movimiento = await Movimiento.findByPk(id);
    if (!movimiento) {
      return res.status(404).json({ error: "Movimiento no encontrado" });
    }
    res.status(200).json(movimiento);
  } catch (error) {
    console.error("Error al obtener movimiento por ID:", error);
    res.status(500).json({ error: "Error al obtener movimiento por ID" });
  }
}

const getMovimientoPorFecha = async (req, res) => {
  try {
    const { fecha } = req.params;
    const movimientos = await Movimiento.findAll({ where: { fecha } });
    if (movimientos.length === 0) {
      return res.status(404).json({ error: "No se encontraron movimientos para la fecha especificada" });
    }
    res.status(200).json(movimientos);
  } catch (error) {
    console.error("Error al obtener movimientos por fecha:", error);
    res.status(500).json({ error: "Error al obtener movimientos por fecha" });
  }
};

const getMovimientoPorCategoria = async (req, res) => {
  try {
    const { id_categoria } = req.params;
    const movimientos = await Movimiento.findAll({ where: { id_categoria } });
    if (movimientos.length === 0) {
      return res.status(404).json({ error: "No se encontraron movimientos para la categoría especificada" });
    }
    res.status(200).json(movimientos);
  } catch (error) {
    console.error("Error al obtener movimientos por categoría:", error);
    res.status(500).json({ error: "Error al obtener movimientos por categoría" });
  }
};

const getMovimientoPorTotal = async (req, res) => {
  try {
    const { total } = req.params;
    const movimientos = await Movimiento.findAll({ where: { total } });
    if (movimientos.length === 0) {
      return res.status(404).json({ error: "No se encontraron movimientos con el total especificado" });
    }
    res.status(200).json(movimientos);
  } catch (error) {
    console.error("Error al obtener movimientos por total:", error);
    res.status(500).json({ error: "Error al obtener movimientos por total" });
  }
};

module.exports = {
  list,
  create,
  update,
  remove,
  getMovimientoPorId,
  getMovimientoPorFecha,
  getMovimientoPorCategoria,
  getMovimientoPorTotal
};
