const { Sequelize } = require("sequelize")
const config = require("../config/database")

const env = process.env.NODE_ENV || "development"
const dbConfig = config[env]

const sequelize = new Sequelize(dbConfig.database, dbConfig.username, dbConfig.password, {
  host: dbConfig.host,
  port: dbConfig.port,
  dialect: dbConfig.dialect,
  logging: dbConfig.logging,
  pool: dbConfig.pool,
  dialectOptions: dbConfig.dialectOptions,
})

// Importar modelos
const Categoria = require("./entintys/categoria")
const Movimiento = require("./entintys/movimientos")

// Definir relaciones
Categoria.hasMany(Movimiento, {
  foreignKey: "id_categoria",
  as: "movimientos",
})

Movimiento.belongsTo(Categoria, {
  foreignKey: "id_categoria",
  as: "categoria",
})

module.exports = {
  sequelize,
  Sequelize,
  Categoria,
  Movimiento,
}