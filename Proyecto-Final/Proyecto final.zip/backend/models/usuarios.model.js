const { Usuario } = require('../models/entities/usuarios.js');

const createUsuario = async (nombre, email, password) => {
  try {
        const usuario = await Usuario.create({ nombre, email, password });
        return usuario;
    } catch (error) {
        throw new Error('Error al crear el usuario');
    }
};

const validate = async (email, password) => {
    try {
        const usuario = await Usuario.findOne({ where: { email } });
        if (!usuario) {
            throw new Error('Usuario no encontrado');
        }
        if (usuario.password !== password) {
            throw new Error('Contraseña incorrecta');
        }
        return usuario;
    } catch (error) {
        throw new Error('Error al validar el usuario');
    }
};

module.exports = {
    createUsuario,
    validate,
};

